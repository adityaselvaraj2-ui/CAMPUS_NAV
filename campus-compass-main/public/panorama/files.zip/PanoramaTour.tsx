import { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { Campus } from '@/data/campusData';

// ─── CAMPUS GUARD ─────────────────────────────────────────────────────────────
// 360° Tour is EXCLUSIVELY available for SJCE.
// Guard fires at render level — Three.js scene never initialises for other campuses.
const ALLOWED_CAMPUS = 'SJCE';

// ─── Image paths — place all 6 JPGs in your /public/panoramas/ folder ─────────
// e.g. public/panoramas/Auditorium.jpg
// Vite serves public/ at root, so the path becomes /panoramas/Auditorium.jpg
const PANORAMA_IMAGES: Record<string, string> = {
  Auditorium:        '/panoramas/Auditorium.jpg',
  BasketBall_Court:  '/panoramas/BasketBall_Court.jpg',
  First_Year_Block:  '/panoramas/First_Year_Block.jpg',
  Main_Entrance:     '/panoramas/Main_Entrance.jpg',
  Mess_And_Canteen:  '/panoramas/Mess_And_Canteen.jpg',
  Second_Year_Block: '/panoramas/Second_Year_Block.jpg',
};

// ─── Location Metadata ────────────────────────────────────────────────────────
interface PanoramaLocation {
  id: string;
  label: string;
  sublabel: string;
  icon: string;
  color: string;
  description: string;
  tags: string[];
}

const SJCE_LOCATIONS: PanoramaLocation[] = [
  {
    id: 'Auditorium',
    label: 'Indoor Auditorium',
    sublabel: 'Main Events Venue',
    icon: '🎭',
    color: '#00D2FF',
    description: 'Capacity 2000+ · Air-conditioned · Dolby sound system',
    tags: ['EVENTS', 'AC', '2000 CAP'],
  },
  {
    id: 'BasketBall_Court',
    label: 'Basketball Court',
    sublabel: 'Outdoor Sports Complex',
    icon: '🏀',
    color: '#FF6B35',
    description: 'Professional flooring · Floodlit · Open 6AM–9PM',
    tags: ['SPORTS', 'OUTDOOR', 'FLOODLIT'],
  },
  {
    id: 'First_Year_Block',
    label: 'First Year Block',
    sublabel: 'Block 1 · Block 2 · Block 3',
    icon: '🎓',
    color: '#06D6A0',
    description: '3 academic blocks · 60+ classrooms · Common labs',
    tags: ['ACADEMIC', '3 BLOCKS', '60+ ROOMS'],
  },
  {
    id: 'Main_Entrance',
    label: 'Main Entrance',
    sublabel: 'Innovation Centre & Exam Hall',
    icon: '🚪',
    color: '#FFD166',
    description: 'Main gate · Innovation Centre · Exam Cell · Seminar Hall',
    tags: ['ENTRANCE', 'INNOVATION', 'EXAMS'],
  },
  {
    id: 'Mess_And_Canteen',
    label: 'Mess & Canteen',
    sublabel: 'Food Court · Dining Hub',
    icon: '🍽️',
    color: '#EF476F',
    description: 'Boys/Girls Mess · Canteen · Open 7AM–10PM',
    tags: ['FOOD', 'MESS', '7AM–10PM'],
  },
  {
    id: 'Second_Year_Block',
    label: 'Second Year Block',
    sublabel: 'Block 4 · Block 12',
    icon: '🏛️',
    color: '#7B2FFF',
    description: 'ECE · Bio Technology · 4 floors · 80+ rooms',
    tags: ['ACADEMIC', 'ECE', 'BIO TECH'],
  },
];

// ─── Campus Blocked Screen ────────────────────────────────────────────────────
const CampusBlockedScreen = ({ campusName }: { campusName: string }) => (
  <div className="flex flex-col items-center justify-center min-h-[60vh] px-6 text-center">
    <div
      className="w-20 h-20 rounded-2xl mb-6 flex items-center justify-center text-4xl"
      style={{ background: 'rgba(239,71,111,0.1)', border: '1px solid rgba(239,71,111,0.3)' }}
    >
      🔒
    </div>
    <div className="font-mono text-xs tracking-widest text-red-400 mb-2">ACCESS RESTRICTED</div>
    <h2 className="font-bold text-xl text-white mb-3">360° Tour Unavailable</h2>
    <p className="font-mono text-sm text-gray-400 max-w-sm leading-relaxed mb-6">
      The 360° Virtual Campus Tour is exclusively available for{' '}
      <span className="text-cyan-400 font-bold">SJCE campus</span>. You are currently
      viewing <span style={{ color: '#EF476F' }} className="font-bold">{campusName}</span>.
    </p>
    <div className="flex flex-col gap-2 w-full max-w-xs">
      <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/5 border border-white/10">
        <span className="text-lg">✅</span>
        <div className="text-left">
          <div className="font-mono text-xs text-cyan-400">SJCE</div>
          <div className="font-mono text-[9px] text-gray-500">360° tour available · 6 locations</div>
        </div>
      </div>
      <div className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/5 border border-red-500/20">
        <span className="text-lg">🚫</span>
        <div className="text-left">
          <div className="font-mono text-xs text-red-400">SJIT / CIT</div>
          <div className="font-mono text-[9px] text-gray-500">360° photos not yet captured</div>
        </div>
      </div>
    </div>
  </div>
);

// ─── Panorama Viewer ──────────────────────────────────────────────────────────
interface PanoramaViewerProps {
  location: PanoramaLocation;
  allLocations: PanoramaLocation[];
  onExit: () => void;
  onNavigate: (id: string) => void;
}

const PanoramaViewer = ({ location, allLocations, onExit, onNavigate }: PanoramaViewerProps) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const animIdRef = useRef<number>(0);

  // All interaction state in refs — zero setState in rAF loop
  const isDraggingRef = useRef(false);
  const lastPointerRef = useRef({ x: 0, y: 0 });
  const sphericalRef = useRef({ theta: 0, phi: Math.PI / 2 });
  const fovRef = useRef(75);
  const gyroActiveRef = useRef(false);
  const gyroOffsetRef = useRef<number | null>(null);
  const touchDistRef = useRef(0);

  // Only these need state — they drive UI, not the render loop
  const [isLoading, setIsLoading] = useState(true);
  const [gyroAvailable, setGyroAvailable] = useState(false);
  const [gyroEnabled, setGyroEnabled] = useState(false);
  const [fps, setFps] = useState(60);

  // ── Bootstrap Three.js scene ───────────────────────────────────────────────
  useEffect(() => {
    if (!mountRef.current) return;
    const mount = mountRef.current;
    const W = mount.clientWidth;
    const H = mount.clientHeight;

    // Scene
    const scene = new THREE.Scene();

    // Camera — positioned at origin, looks outward into the sphere
    const camera = new THREE.PerspectiveCamera(75, W / H, 0.1, 1000);
    camera.position.set(0, 0, 0.01); // epsilon prevents z-fighting
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(W, H);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // cap GPU load on retina
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    rendererRef.current = renderer;
    mount.appendChild(renderer.domElement);

    // ── Load texture from public/panoramas/ ───────────────────────────────
    const loader = new THREE.TextureLoader();
    loader.load(
      PANORAMA_IMAGES[location.id],
      (texture) => {
        texture.colorSpace = THREE.SRGBColorSpace; // gamma-correct colour decode
        texture.minFilter = THREE.LinearFilter;    // smooth on zoom-in
        texture.magFilter = THREE.LinearFilter;    // smooth on zoom-out
        texture.generateMipmaps = false;           // equirect doesn't need mipmaps
        texture.wrapS = THREE.RepeatWrapping;
        texture.repeat.x = -1;                    // mirror X — fixes E/W flip inside sphere

        // SphereGeometry(radius, widthSegments, heightSegments)
        // BackSide: renders inner surface — user sits at origin looking outward
        const geo = new THREE.SphereGeometry(500, 64, 32);
        const mat = new THREE.MeshBasicMaterial({ map: texture, side: THREE.BackSide });
        scene.add(new THREE.Mesh(geo, mat));
        setIsLoading(false);
      },
      undefined,
      (err) => console.error('[PanoramaTour] Texture load failed:', err)
    );

    // ── Render loop — zero state mutations here ────────────────────────────
    let frameCount = 0;
    let lastFpsTime = performance.now();

    const animate = () => {
      animIdRef.current = requestAnimationFrame(animate);

      // Auto-rotate only when neither dragging nor gyro is active
      if (!isDraggingRef.current && !gyroActiveRef.current) {
        sphericalRef.current.theta += 0.0003;
      }

      // Spherical → Cartesian lookAt vector
      const { theta, phi } = sphericalRef.current;
      camera.fov = fovRef.current;
      camera.updateProjectionMatrix();
      camera.lookAt(
        Math.sin(phi) * Math.cos(theta),
        Math.cos(phi),
        Math.sin(phi) * Math.sin(theta)
      );

      renderer.render(scene, camera);

      // FPS: update UI only once per second
      frameCount++;
      const now = performance.now();
      if (now - lastFpsTime >= 1000) {
        setFps(Math.round((frameCount * 1000) / (now - lastFpsTime)));
        frameCount = 0;
        lastFpsTime = now;
      }
    };
    animate();

    // ── Resize handler ────────────────────────────────────────────────────
    const onResize = () => {
      const W2 = mount.clientWidth;
      const H2 = mount.clientHeight;
      camera.aspect = W2 / H2;
      camera.updateProjectionMatrix();
      renderer.setSize(W2, H2);
    };
    window.addEventListener('resize', onResize);

    // ── Gyro availability check ───────────────────────────────────────────
    if ('DeviceOrientationEvent' in window) setGyroAvailable(true);

    // ── Cleanup — GPU memory must be freed on unmount ─────────────────────
    return () => {
      cancelAnimationFrame(animIdRef.current);
      window.removeEventListener('resize', onResize);
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
      renderer.dispose();
      rendererRef.current = null;
    };
  }, [location.id]); // re-runs when location changes → new texture loaded

  // ── Gyroscope ─────────────────────────────────────────────────────────────
  const handleDeviceOrientation = useCallback((e: DeviceOrientationEvent) => {
    if (!gyroActiveRef.current) return;

    const alpha = e.alpha ?? 0; // compass heading 0–360°
    const beta  = e.beta  ?? 90; // front-back tilt -180–180°

    // Save offset on first event → current facing becomes "forward"
    if (gyroOffsetRef.current === null) gyroOffsetRef.current = alpha;

    const heading = ((alpha - gyroOffsetRef.current) * Math.PI) / 180;
    const tilt    = ((90 - beta) * Math.PI) / 180;

    sphericalRef.current = {
      theta: -heading,
      phi: Math.max(0.1, Math.min(Math.PI - 0.1, tilt)),
    };
  }, []);

  const enableGyro = useCallback(async () => {
    // iOS Safari requires explicit permission — must be triggered by user gesture
    if (typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
      const result = await (DeviceOrientationEvent as any).requestPermission();
      if (result !== 'granted') return;
    }
    gyroActiveRef.current = true;
    gyroOffsetRef.current = null; // reset offset for fresh calibration
    window.addEventListener('deviceorientationabsolute', handleDeviceOrientation as EventListener, true);
    window.addEventListener('deviceorientation', handleDeviceOrientation, true);
    setGyroEnabled(true);
  }, [handleDeviceOrientation]);

  const disableGyro = useCallback(() => {
    gyroActiveRef.current = false;
    window.removeEventListener('deviceorientationabsolute', handleDeviceOrientation as EventListener, true);
    window.removeEventListener('deviceorientation', handleDeviceOrientation, true);
    setGyroEnabled(false);
  }, [handleDeviceOrientation]);

  useEffect(() => {
    return () => {
      // Cleanup gyro listeners on unmount
      window.removeEventListener('deviceorientationabsolute', handleDeviceOrientation as EventListener, true);
      window.removeEventListener('deviceorientation', handleDeviceOrientation, true);
    };
  }, [handleDeviceOrientation]);

  // ── Pointer drag ──────────────────────────────────────────────────────────
  const onPointerDown = useCallback((e: React.PointerEvent) => {
    isDraggingRef.current = true;
    lastPointerRef.current = { x: e.clientX, y: e.clientY };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  }, []);

  const onPointerMove = useCallback((e: React.PointerEvent) => {
    if (!isDraggingRef.current) return;
    const dx = e.clientX - lastPointerRef.current.x;
    const dy = e.clientY - lastPointerRef.current.y;
    lastPointerRef.current = { x: e.clientX, y: e.clientY };
    sphericalRef.current.theta -= dx * 0.004;
    sphericalRef.current.phi = Math.max(
      0.1,
      Math.min(Math.PI - 0.1, sphericalRef.current.phi - dy * 0.004)
    );
  }, []);

  const onPointerUp = useCallback(() => {
    isDraggingRef.current = false;
  }, []);

  // ── Scroll to zoom ────────────────────────────────────────────────────────
  const onWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    fovRef.current = Math.max(30, Math.min(100, fovRef.current + e.deltaY * 0.05));
  }, []);

  // ── Pinch to zoom ─────────────────────────────────────────────────────────
  const onTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      touchDistRef.current = Math.sqrt(dx * dx + dy * dy);
    }
  }, []);

  const onTouchMove = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const newDist = Math.sqrt(dx * dx + dy * dy);
      fovRef.current = Math.max(30, Math.min(100, fovRef.current + (touchDistRef.current - newDist) * 0.1));
      touchDistRef.current = newDist;
    }
  }, []);

  return (
    <div className="fixed inset-0 z-[2000] bg-black flex flex-col">
      {/* Three.js canvas mount */}
      <div
        ref={mountRef}
        className="absolute inset-0 cursor-grab active:cursor-grabbing"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerLeave={onPointerUp}
        onWheel={onWheel}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
      />

      {/* Loading overlay */}
      {isLoading && (
        <div className="absolute inset-0 z-50 bg-black flex flex-col items-center justify-center">
          <div className="relative w-16 h-16 mb-4">
            <div className="absolute inset-0 rounded-full border-2 border-white/10" />
            <div
              className="absolute inset-0 rounded-full border-2 border-transparent border-t-current animate-spin"
              style={{ color: location.color }}
            />
          </div>
          <div className="font-mono text-xs tracking-widest animate-pulse" style={{ color: location.color }}>
            LOADING 360° · {location.label.toUpperCase()}
          </div>
        </div>
      )}

      {/* Top HUD */}
      <div
        className="absolute top-0 left-0 right-0 z-40 flex items-center justify-between px-4 py-3"
        style={{ background: 'linear-gradient(to bottom, rgba(0,0,0,0.75), transparent)' }}
      >
        {/* Exit */}
        <button
          onClick={onExit}
          className="px-3 py-1.5 rounded-lg font-mono text-xs text-white bg-black/50
                     border border-white/20 hover:bg-black/70 transition-all backdrop-blur-sm"
        >
          ← EXIT 360°
        </button>

        {/* Location badge */}
        <div
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-black/50
                     border backdrop-blur-sm"
          style={{ borderColor: `${location.color}50` }}
        >
          <span className="text-base">{location.icon}</span>
          <div>
            <div className="font-mono text-[10px] font-bold" style={{ color: location.color }}>
              {location.label.toUpperCase()}
            </div>
            <div className="font-mono text-[8px] text-white/50">{location.sublabel}</div>
          </div>
        </div>

        {/* Gyro + FPS */}
        <div className="flex items-center gap-2">
          {gyroAvailable && (
            <button
              onClick={gyroEnabled ? disableGyro : enableGyro}
              className="px-3 py-1.5 rounded-lg font-mono text-xs border transition-all backdrop-blur-sm"
              style={{
                background: gyroEnabled ? `${location.color}20` : 'rgba(0,0,0,0.5)',
                borderColor: gyroEnabled ? location.color : 'rgba(255,255,255,0.2)',
                color: gyroEnabled ? location.color : 'rgba(255,255,255,0.6)',
              }}
            >
              {gyroEnabled ? '📡 GYRO ON' : '📱 GYRO'}
            </button>
          )}
          <div className="px-2 py-1 rounded bg-black/50 font-mono text-[9px] text-white/40 border border-white/10">
            {fps}fps
          </div>
        </div>
      </div>

      {/* Crosshair */}
      {!isLoading && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30">
          <div className="relative w-8 h-8">
            <div className="absolute top-1/2 left-0 right-0 h-px -translate-y-px"
              style={{ background: `${location.color}70` }} />
            <div className="absolute left-1/2 top-0 bottom-0 w-px -translate-x-px"
              style={{ background: `${location.color}70` }} />
            <div className="absolute inset-2 rounded-full border"
              style={{ borderColor: `${location.color}50` }} />
          </div>
        </div>
      )}

      {/* Bottom instructions */}
      {!isLoading && (
        <div
          className="absolute bottom-0 left-0 right-0 z-40 flex flex-col items-center gap-3 pb-4 pt-16"
          style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.75), transparent)' }}
        >
          {/* Location switcher strip */}
          <div className="flex gap-2 overflow-x-auto px-4 pb-1 max-w-full">
            {allLocations.map((loc) => (
              <button
                key={loc.id}
                onClick={() => onNavigate(loc.id)}
                className="flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg
                           font-mono text-[9px] border transition-all backdrop-blur-sm whitespace-nowrap"
                style={{
                  background: loc.id === location.id ? `${loc.color}20` : 'rgba(0,0,0,0.5)',
                  borderColor: loc.id === location.id ? loc.color : 'rgba(255,255,255,0.15)',
                  color: loc.id === location.id ? loc.color : 'rgba(255,255,255,0.5)',
                }}
              >
                <span>{loc.icon}</span>
                <span>{loc.label}</span>
              </button>
            ))}
          </div>

          {/* Hint pill */}
          <div className="px-4 py-1.5 rounded-full bg-black/50 border border-white/10
                          font-mono text-[9px] text-white/40 tracking-wider backdrop-blur-sm">
            {gyroEnabled
              ? 'TILT DEVICE TO LOOK AROUND · PINCH TO ZOOM'
              : 'DRAG TO LOOK AROUND · SCROLL TO ZOOM'}
          </div>
        </div>
      )}
    </div>
  );
};

// ─── Selection Hub ─────────────────────────────────────────────────────────────
interface PanoramaTourProps {
  campus: Campus;
  onExit?: () => void;
}

const PanoramaTour = ({ campus, onExit }: PanoramaTourProps) => {
  const [activeLocationId, setActiveLocationId] = useState<string | null>(null);

  // ── CAMPUS GUARD — hard block for SJIT and CIT ──────────────────────────
  if (campus.shortName !== ALLOWED_CAMPUS) {
    return <CampusBlockedScreen campusName={campus.shortName} />;
  }

  // ── Active panorama viewer ───────────────────────────────────────────────
  if (activeLocationId) {
    const location = SJCE_LOCATIONS.find((l) => l.id === activeLocationId)!;
    return (
      <PanoramaViewer
        location={location}
        allLocations={SJCE_LOCATIONS}
        onExit={() => setActiveLocationId(null)}
        onNavigate={(id) => setActiveLocationId(id)}
      />
    );
  }

  // ── Selection hub ────────────────────────────────────────────────────────
  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-3 mb-4">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
            style={{ background: 'rgba(0,210,255,0.1)', border: '1px solid rgba(0,210,255,0.3)' }}
          >
            🌐
          </div>
          <div className="text-left">
            <div className="font-mono text-[10px] tracking-widest text-gray-400">SJCE CAMPUS ONLY</div>
            <div className="font-bold text-2xl text-white">360° VIRTUAL TOUR</div>
          </div>
        </div>
        <p className="font-mono text-sm text-gray-400 max-w-md mx-auto">
          Real 360° photos shot on SJCE campus. Click any location to step inside.
          Drag on desktop or tilt your phone with gyroscope to look around.
        </p>

        {/* Feature pills */}
        <div className="flex flex-wrap justify-center gap-2 mt-4">
          {['📡 Gyroscope Control', '🖱️ Drag to Look', '🔍 Pinch/Scroll Zoom', '⚡ WebGL Rendered', '📴 Works Offline'].map((f) => (
            <span
              key={f}
              className="font-mono text-[9px] px-3 py-1 rounded-full border border-white/10 bg-white/5 text-gray-400"
            >
              {f}
            </span>
          ))}
        </div>
      </div>

      {/* Location grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {SJCE_LOCATIONS.map((loc, i) => (
          <button
            key={loc.id}
            onClick={() => setActiveLocationId(loc.id)}
            className="group relative rounded-2xl overflow-hidden text-left border
                       bg-black/40 backdrop-blur-sm hover:-translate-y-2
                       active:translate-y-0 transition-all duration-300"
            style={{
              borderColor: `${loc.color}30`,
              animationDelay: `${i * 80}ms`,
            }}
          >
            {/* Hover glow */}
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
              style={{ background: `radial-gradient(ellipse at 50% 0%, ${loc.color}18, transparent 70%)` }}
            />

            {/* Top accent line */}
            <div
              className="h-0.5 w-full"
              style={{ background: `linear-gradient(90deg, transparent, ${loc.color}, transparent)` }}
            />

            <div className="p-5 relative z-10">
              {/* Icon + badge */}
              <div className="flex items-start justify-between mb-4">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                  style={{ background: `${loc.color}15`, border: `1px solid ${loc.color}30` }}
                >
                  {loc.icon}
                </div>
                <span
                  className="font-mono text-[8px] px-2 py-1 rounded-md border"
                  style={{ color: loc.color, background: `${loc.color}10`, borderColor: `${loc.color}30` }}
                >
                  360° LIVE
                </span>
              </div>

              {/* Text */}
              <div className="font-bold text-white text-sm mb-0.5">{loc.label}</div>
              <div className="font-mono text-[10px] text-gray-400 mb-2">{loc.sublabel}</div>
              <div className="font-mono text-[9px] text-gray-500 mb-3">{loc.description}</div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5">
                {loc.tags.map((tag) => (
                  <span
                    key={tag}
                    className="font-mono text-[8px] px-2 py-0.5 rounded-md bg-white/5 text-gray-400 border border-white/10"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Launch hint */}
              <div
                className="mt-4 flex items-center gap-1.5 font-mono text-[10px]
                           opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ color: loc.color }}
              >
                <span>▶</span>
                <span>ENTER 360° VIEW</span>
              </div>
            </div>
          </button>
        ))}
      </div>

      {onExit && (
        <div className="text-center mt-8">
          <button
            onClick={onExit}
            className="font-mono text-xs text-gray-500 hover:text-gray-300 transition-colors"
          >
            ← BACK TO AR/VR SUITE
          </button>
        </div>
      )}
    </div>
  );
};

export default PanoramaTour;
